﻿using System;


namespace CoinApplication {

    class CoinTossing {

        static void Main(string[] args) {
            // declare 2 counter variables

            // declare a Coin variable and create (instantiate) the Coin object

            Console.WriteLine("Welcome to 1000 Coin Toss Simulation\n");

            // repeat the following 1000 times
            //   flip the Coin object
            //   if Coin shows a Head
            //      increment Head counter
            //   else 
            //       increment Tail Counter
            //   end if
            // end repeat


           // Output result of 1000 coin tosses
            
            
            Console.Write("\n\n Press any key to continue ...");
            Console.ReadKey();

        }
    }
}
