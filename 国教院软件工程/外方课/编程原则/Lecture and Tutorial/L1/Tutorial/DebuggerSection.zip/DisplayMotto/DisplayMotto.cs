/* DisplayMotto.cs 
 * This program displays a well known saying.
 */

using System;

namespace DisplayMotto
{	
	class DisplayMotto
	{		
		static void Main() {
			Console.WriteLine("\n\t\t  The\n");
			Console.WriteLine("\t\t harder\n");
			Console.WriteLine("\t\t  you\n");
			Console.WriteLine("\t\t  work,\n");
			Console.WriteLine("\t\t  the\n");
			Console.WriteLine("\t\tluckier\n");
			Console.WriteLine("\t\t  you\n");
			Console.WriteLine("\t\t  get.\n\n\n\n\n\n");
		}
	}
}
